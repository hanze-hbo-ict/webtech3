<?php

function getRandomString() {
    $length = rand(3,12);
    $characters = 'abcdefghijklmnopqrstuvwxyz';
    $randomString = '';

    for ($i=0; $i < $length; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return ucfirst($randomString);
}

function getScores() {
    $rv = [];
    $tot = rand(25, 250);
    for ($i=0; $i<$tot; $i++) {
        $score = rand  (10,255);
        $rv[] = $score;
    }
    return $rv;
}

$tot = [];
for ($i=0; $i<rand(100, 400); $i++) {
    $name = getRandomString() . " " . getRandomString();
    $tot[] = [ "name" => $name, "scores" => getScores() ];
}

header("Access-Control-Allow-Origin: http://localhost:8080"); 
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Your existing PHP code

try {
    $hash_check = password_hash('OpDeTank', null);
    if ($_POST['username']=='Henk' && password_verify($_POST['password'], $hash_check)) {
        header("Content-Type:Application/json");
        print json_encode($tot);
    } else {
       header ('HTTP/1.0 401 Unauthorized');
    }
} catch (Exception $e) {
   header ('HTTP/1.0 400 Illegal Request');
}


const template = document.createElement('template')
template.innerHTML = `
<style>
    :host { display:block; background-color:white; width:100%; border-radius:5px;}
    div.card { display:flex; padding:4% 6%; }
    img { border-radius:50%; }
    div.content { margin-left:5%; }
    h4 { font-size:1.2rem; }
</style>

<div class="card">
    <div class="image">
        <img>
    </div>
    <div class="content">
        <h4></h4>
        <p></p>
    </div>
</div>
`

class PersonCard extends HTMLElement {
  // OPDRACHT 1

}

window.customElements.define('person-card', PersonCard)
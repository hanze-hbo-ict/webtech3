import { Component } from '@angular/core';
import { searchdata } from './interfaces';

@Component({
  selector: 'app-root',
  template: `
    <h4>Voorbeeld van werken met meerdere modules</h4>
    <!-- 
       OPDRACHT 2: voorzie deze componenten van een event-handler die 
       reageert op het doorsturen van nieuwe data
    -->
    <docent-search></docent-search>
    <student-search></student-search>

    <!-- OPDRACHT 3: stuur de waarde van 'searchdata' door naar het 
      search-result component
    --> 
    <search-result></search-result>
  `
})
export class AppComponent { 

  searchdata?:searchdata

  handleNewData(e:Event) {
    // OPDRACHT 1b
  }
}

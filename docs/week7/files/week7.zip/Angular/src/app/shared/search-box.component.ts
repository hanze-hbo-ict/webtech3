import { Component, ElementRef, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'search-box',
  template: `
    <span>
    <!-- OPDRACHT 2A: events toevoegen aan deze html -->
      <input #searchbox type="text" style="width: 25%" placeholder="Search">
      <i class="material-icons" style="position: relative;top: 7px;cursor:pointer;">search</i>
    </span>
  `
})
export class SearchBoxComponent { 
  @Input() searchItem = ""
  @Output() newdata = new EventEmitter<String>()

  constructor (private el:ElementRef) {}

  handleEvent(searchstring:String) {
    /* OPDRACHT 2A */
    /* OPDRACHT 3C */
  }
}



import { Component, Input, OnInit, OnChanges, SimpleChange, SimpleChanges } from '@angular/core';
import { Docent, searchdata, Student } from '../interfaces';
import { docentdata, studentdata } from '../data';
import { StudentSearchComponent } from '../cards/student-search.component';


@Component({
  selector: 'search-result',
  templateUrl: './search-result.component.html',
})
export class SearchResultComponent implements OnInit, OnChanges {

  @Input() searchdata?:searchdata
  docentdata?:Docent
  studentdata?:Student


  // OPDRACHT 3C: injecteer de DataService
  constructor() { }


  ngOnInit(): void {
    /* OPDRACHT 3B: 
      abonneer deze klasse op de streams van de dataservice
      (je zult die dataservice nog wel moeten injecteren)
    */
  }

  ngOnChanges(changes: SimpleChanges): void {
    /* OPDRACHT 2C: 
      Zorg er hier voor dat de juiste data wordt opgeslagen
      in het veld `docentdata` of `studentdata`
    */
  }
}
